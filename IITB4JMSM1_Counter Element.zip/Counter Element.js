let counterElement = document.getElementById("counterValue");


function onDecrement() {
    let previousCounterValue = counterElement.textContent;
    let updatedCounterValue = parseInt(previousCounterValue) - 1;
    counterElement.textContent = updatedCounterValue - 1;
}

function onRest() {
    let updatedCounterValue = 0;
    counterElement.textContent = updatedCounterValue;
}

function onIncrement() {
    let previousCounterValue = counterElement.textContent;
    let updatedCounterValue = parseInt(previousCounterValue) + 1;
    counterElement.textContent = updatedCounterValue + 1;
}